from django.contrib import admin
from .models import User, Trade, Rock

admin.site.register(User)
admin.site.register(Trade)
admin.site.register(Rock)